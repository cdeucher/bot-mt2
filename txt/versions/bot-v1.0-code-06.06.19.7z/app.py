import time, sys, keyboard, cv2

from screen import grab_screen
from metin2.mt2 import check_open_game, click
from metin2.IA import A_I_predict
from cv2Lib import process_img, process_img_my

def main():
  last_time    = time.time()-10
  win_position = check_open_game()
  print('position current -',win_position)


  while win_position:    

    #time.sleep(1)
    if time.time()-last_time >= 1:
      #screen
      screen = grab_screen(region=win_position)
      print('Frame took {} seconds'.format(time.time()-last_time))
      last_time = time.time()

      original_image = process_img_my(screen) 
      img_gray = cv2.cvtColor(original_image, cv2.COLOR_BGR2GRAY)

      #---- match
      if True:
        img_gray = A_I_predict(cv2, img_gray)
                
      #------
      #cv2.imshow('window', original_image)
      cv2.imshow('window',img_gray)
      cv2.resizeWindow('window', win_position[2],win_position[3])      
            
      if cv2.waitKey(25) & 0xFF == ord('q'):
          print('close2')
          cv2.destroyAllWindows()
          break

      #click(last_mob, win_position, ahk)
    if keyboard.is_pressed('q'):
        print('close')
        cv2.destroyAllWindows()
        sys.exit() 
 

if __name__ == "__main__":
  main()   
    