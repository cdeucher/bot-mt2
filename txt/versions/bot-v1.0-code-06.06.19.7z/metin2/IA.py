
import numpy as np

def A_I_predict(cv2, img_gray):
    lvl = ['match/one.jpg']

    for img in lvl:
        template = cv2.imread(img,0)
        w, h = template.shape[::-1]
        res = cv2.matchTemplate(img_gray,template,cv2.TM_CCOEFF_NORMED)

        threshold = 0.6
        loc = np.where( res >= threshold)
        
        last_mob = False
        for pt in zip(*loc[::-1]):
            if last_mob == False:
                last_mob = pt  
                print(pt)                       
            font = cv2.FONT_HERSHEY_SIMPLEX
            cv2.putText(img_gray, str(pt[0])+'x'+str(pt[1]) ,(pt[0],pt[1]), font, 0.5,(255,255,255),2,cv2.LINE_AA)
            cv2.rectangle(img_gray, ( pt[0]+70,pt[1]+50 ), (pt[0] + w, pt[1] + h), (0,255,255), 2)

    return img_gray        