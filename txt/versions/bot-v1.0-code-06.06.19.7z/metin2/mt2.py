import time
from ahk import AHK
ahk = AHK()

def check_open_game():
  try:

    win = ahk.find_window(title=b'METIN2')
    win.activate()

    for window in ahk.windows():
        if window.title == b'METIN2':
          return window.rect
    return (0,0,0,0)

  except AttributeError: 
    print('no game open')
    return False

def click(position, win_position, ahk):
  try:
    click_position = (position[0]+win_position[0]+35 , position[1]+win_position[1]+ 25)

    print(click_position)
    #ahk.mouse_move(position[0]+win_position[0]+100 , position[1]+win_position[1]+ 120, speed=10, blocking=True) 
    ahk.mouse_position = click_position
    ahk.click()

    time.sleep(3)
    moveMetin2x(ahk)

  except Exception as e:
    print('fail click')

    ahk.key_down('a')
    time.sleep(2)
    ahk.key_up('a')

def moveMetin2x(ahk):
    print('running start skill')
    ahk.key_press('3')
    ahk.key_press('4')

    print('running start pot')
    ahk.key_press('3')
    print('running start atk')

    ahk.key_press('f3') 
    ahk.key_down('Space')    
    time.sleep(3)
    ahk.key_up('Space')
    ahk.key_press('f3') 
    ahk.key_press('f4') 

    ahk.key_down('a')
    time.sleep(2)
    ahk.key_up('a')

    ahk.key_press('s')
    ahk.key_press('s')    