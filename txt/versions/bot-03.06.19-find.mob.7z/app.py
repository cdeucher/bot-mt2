import time, sys
import cv2
import keyboard
import numpy as np

from screen import grab_screen
from move import moveESO, moveMetin2, click, moveMetin2x
from cv2Lib import process_img, process_img_my

from ahk import AHK
ahk = AHK()

def main():
  last_time    = time.time()-10
  win_position = moveESO(ahk)
  print('position current -',win_position)


  while True:    

    #time.sleep(1)
    if time.time()-last_time >= 1:
      #screen
      screen = grab_screen(region=win_position)
      print('Frame took {} seconds'.format(time.time()-last_time))
      last_time = time.time()

      original_image = process_img_my(screen) 
      img_gray = cv2.cvtColor(original_image, cv2.COLOR_BGR2GRAY)

      #---- match
      if True:
        template = cv2.imread('match/xx.jpg',0)
        w, h = template.shape[::-1]
        res = cv2.matchTemplate(img_gray,template,cv2.TM_CCOEFF_NORMED)

        threshold = 0.7
        loc = np.where( res >= threshold)
        
        last_mob = ()
        for pt in zip(*loc[::-1]):
            #print(pt)                       
            font = cv2.FONT_HERSHEY_SIMPLEX
            cv2.putText(img_gray,str(pt[0])+'x'+str(pt[1]),(pt[0],pt[1]), font, 0.5,(255,255,255),2,cv2.LINE_AA)
            cv2.rectangle(img_gray, (pt[0]+100,pt[1]+120), (pt[0] + w, pt[1] + h), (0,255,255), 2)
            last_mob = pt 
        
        #click(last_mob, win_position, ahk)
  
      #------

      #cv2.imshow('window', original_image)
      cv2.imshow('window',img_gray)
      cv2.resizeWindow('window', win_position[2],win_position[3])      
      
      if cv2.waitKey(25) & 0xFF == ord('q'):
          print('close2')
          cv2.destroyAllWindows()
          break

    if keyboard.is_pressed('q'):
        print('close')
        cv2.destroyAllWindows()
        sys.exit() 
 

if __name__ == "__main__":
  main()     