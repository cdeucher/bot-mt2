import time, sys
import cv2
import keyboard

from screen import grab_screen
from move import moveESO,moveMetin2
from cv2Lib import process_img, process_img_my


def main():
  last_time    = time.time()-10
  win_position = moveMetin2()
  print('position current -',win_position)

  while True:    

    #time.sleep(1)
    if time.time()-last_time >= 5:
      #screen
      screen = grab_screen(region=win_position)
      print('Frame took {} seconds'.format(time.time()-last_time))
      last_time = time.time()

      original_image = process_img_my(screen)  
      cv2.imshow('window', original_image)
      cv2.resizeWindow('window', win_position[2],win_position[3])
      #cv2.imshow('window2',cv2.cvtColor(original_image, cv2.COLOR_BGR2GRAY))
      
      if cv2.waitKey(25) & 0xFF == ord('q'):
          print('close2')
          cv2.destroyAllWindows()
          break

    if keyboard.is_pressed('q'):
        print('close')
        cv2.destroyAllWindows()
        sys.exit() 
 

if __name__ == "__main__":
  main()     